### My Personal Web site 


Use From:
    
   1. [Bootstrap](1)
   
   2. [Popper.JS](2)
   
   3. [Typed.Js](3)
   
[**Live Version**](http:Jalambadani.ir).

   

    

[1]:(https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwir6cG2-7niAhX68OAKHdEGDkkQFjAAegQIBhAC&url=https%3A%2F%2Fgetbootstrap.com%2F&usg=AOvVaw3s0qqZzEfHTiGFr9v0jCTN)
[2]:(https://popper.js.org/)
[3]:(https://github.com/mattboldt/typed.js)